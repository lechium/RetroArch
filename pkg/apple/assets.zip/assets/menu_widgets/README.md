See src/menu_widgets/README.md
